chmod +x deps.sh
./deps.sh 
python3 rt_app.py